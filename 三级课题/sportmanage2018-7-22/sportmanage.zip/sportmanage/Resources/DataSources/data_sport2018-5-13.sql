/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50508
Source Host           : localhost:3306
Source Database       : data_sport

Target Server Type    : MYSQL
Target Server Version : 50508
File Encoding         : 65001

Date: 2018-05-13 22:36:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `code_class`
-- ----------------------------
DROP TABLE IF EXISTS `code_class`;
CREATE TABLE `code_class` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_class
-- ----------------------------

-- ----------------------------
-- Table structure for `code_college`
-- ----------------------------
DROP TABLE IF EXISTS `code_college`;
CREATE TABLE `code_college` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_college
-- ----------------------------

-- ----------------------------
-- Table structure for `code_school`
-- ----------------------------
DROP TABLE IF EXISTS `code_school`;
CREATE TABLE `code_school` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_school
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_manager`
-- ----------------------------
DROP TABLE IF EXISTS `tb_manager`;
CREATE TABLE `tb_manager` (
  `id` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work` varchar(20) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_manager
-- ----------------------------
INSERT INTO `tb_manager` VALUES ('1', '1', '小明', '管理员管理', '2018-03-22');
INSERT INTO `tb_manager` VALUES ('2', '1', '昌宗', '注册管理', '2018-05-13');
INSERT INTO `tb_manager` VALUES ('3', '1', '季波', '新闻公告管理', '2018-05-12');
INSERT INTO `tb_manager` VALUES ('4', '4', '姚唧唧', '注册管理员', '2018-04-08');
INSERT INTO `tb_manager` VALUES ('5', '1', 'cui', '注册管理', '2018-05-13');

-- ----------------------------
-- Table structure for `tb_student`
-- ----------------------------
DROP TABLE IF EXISTS `tb_student`;
CREATE TABLE `tb_student` (
  `id` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `nation` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `schoolid` int(5) DEFAULT NULL,
  `collegeid` int(5) DEFAULT NULL,
  `classid` int(5) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `work` varchar(20) DEFAULT NULL,
  `fatherver` varchar(20) DEFAULT NULL,
  `motherver` varchar(20) DEFAULT NULL,
  `homever` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_student
-- ----------------------------
INSERT INTO `tb_student` VALUES ('', '', null, null, null, '2007-01-01', null, null, null, '', '', null, null, null, null);
INSERT INTO `tb_student` VALUES ('20132', '1', null, null, null, '2007-01-01', null, null, null, '137', '1378', null, null, null, null);
INSERT INTO `tb_student` VALUES ('2015', '1', null, null, null, '2006-01-01', null, null, null, '137', '13777', null, null, null, null);
INSERT INTO `tb_student` VALUES ('20161', '', null, null, null, '2007-01-01', null, null, null, '', '', null, null, null, null);
INSERT INTO `tb_student` VALUES ('201612', '', null, null, null, '2007-01-01', null, null, null, '12', '111', null, null, null, null);
INSERT INTO `tb_student` VALUES ('201619140220', '1', '崔烁豪', null, null, '2000-12-02', null, null, null, null, null, null, null, null, null);
INSERT INTO `tb_student` VALUES ('201619140221', '123', null, null, null, '1997-01-01', null, null, null, '1345687', '13564@163.com', null, null, null, null);
INSERT INTO `tb_student` VALUES ('201619140223', '123', null, null, null, '1997-01-01', null, null, null, '1345687', '13564@163.com', null, null, null, null);

-- ----------------------------
-- Table structure for `tb_teacher`
-- ----------------------------
DROP TABLE IF EXISTS `tb_teacher`;
CREATE TABLE `tb_teacher` (
  `id` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `name` varchar(20) NOT NULL,
  `position` varchar(20) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `introduction` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_teacher
-- ----------------------------
INSERT INTO `tb_teacher` VALUES ('20161999', '1', '张三', '教师', '副教授', '院长办公室', null, null);
