/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50508
Source Host           : localhost:3306
Source Database       : data_sport

Target Server Type    : MYSQL
Target Server Version : 50508
File Encoding         : 65001

Date: 2018-03-23 11:21:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `code_class`
-- ----------------------------
DROP TABLE IF EXISTS `code_class`;
CREATE TABLE `code_class` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_class
-- ----------------------------

-- ----------------------------
-- Table structure for `code_college`
-- ----------------------------
DROP TABLE IF EXISTS `code_college`;
CREATE TABLE `code_college` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_college
-- ----------------------------

-- ----------------------------
-- Table structure for `code_school`
-- ----------------------------
DROP TABLE IF EXISTS `code_school`;
CREATE TABLE `code_school` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_school
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_manager`
-- ----------------------------
DROP TABLE IF EXISTS `tb_manager`;
CREATE TABLE `tb_manager` (
  `id` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `name` varchar(20) NOT NULL,
  `work` varchar(20) NOT NULL,
  `workid` int(5) DEFAULT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_manager
-- ----------------------------
INSERT INTO `tb_manager` VALUES ('1', '1', '1', '1', '1', '2018-03-22');
INSERT INTO `tb_manager` VALUES ('a', '123', 'aa', '1', '1', '2018-03-23');

-- ----------------------------
-- Table structure for `tb_student`
-- ----------------------------
DROP TABLE IF EXISTS `tb_student`;
CREATE TABLE `tb_student` (
  `id` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `name` varchar(20) NOT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `nation` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `schoolid` int(5) DEFAULT NULL,
  `collegeid` int(5) DEFAULT NULL,
  `classid` int(5) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `work` varchar(20) DEFAULT NULL,
  `fatherver` varchar(20) DEFAULT NULL,
  `motherver` varchar(20) DEFAULT NULL,
  `homever` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_student
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_teacher`
-- ----------------------------
DROP TABLE IF EXISTS `tb_teacher`;
CREATE TABLE `tb_teacher` (
  `id` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `name` varchar(20) NOT NULL,
  `position` varchar(20) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `introduction` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_teacher
-- ----------------------------
