function jump()
{
	window.location.href="/sportmanage/sportManage/html/index.html";
}