var div1=document.getElementById("div1");
var div2=document.getElementById("div2");
var btn=document.getElementById("btn");
var showBox=document.getElementById("show-box");
