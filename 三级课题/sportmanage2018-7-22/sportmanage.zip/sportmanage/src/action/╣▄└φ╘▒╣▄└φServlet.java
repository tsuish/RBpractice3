package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ManagerDao;
import dao.entity;
//接收请求：管理员管理.java
public class 管理员管理Servlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String choice=request.getParameter("choice");//所选管理员的账号
		String exe=request.getParameter("exe");//修改、添加、删除
		String path="";
		if(exe.equals("添加")){
			path="/添加管理员";
			RequestDispatcher rd = request.getRequestDispatcher(path);
			rd.forward(request, response);
		}else if(choice==null||exe==""){
			out.print("请选择一个管理员"
				+ "<form action='管理员管理'>"
				+ "<input type='submit' value='确认'>"
				+ "</form>");
		}else if(exe.equals("删除")){
			ManagerDao manager=new ManagerDao();
			boolean havedele=false;
			havedele=manager.delete(choice);
			if(havedele){
				out.println("<HTML>");
				out.println("  <HEAD><TITLE>删除管理员</TITLE></HEAD>");
				out.println("  <BODY>"
						+ "删除成功！"
						+ "<form action='管理员管理'>"
						+ "<input type='submit' value='确认'>"
						+ "</form>"
						+ "");
				out.println("  </BODY>");
				out.println("</HTML>");
			}
		}else if(exe.equals("修改")){
			path="/修改管理员";
			request.setAttribute("id",choice);
			RequestDispatcher rd = request.getRequestDispatcher(path);//转发时，路径不要带项目名
			rd.forward(request, response);
		}
		
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
