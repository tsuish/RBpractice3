package action;
/*
 * servlet
 * 接收从"登录.html"传来的用户密码数据,
 * 并与数据库做对比,
 * 如果帐号密码正确,转向"登录后首页.html".
 * */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.LoginDao;
import dao.ManagerDao;
import dao.entity;
public class LoginServlet extends HttpServlet {	
	/*
	 * 默认doGet
	 * doGet会在url中显示parameter属性
	 * doGet的参数放在HTTP请求报文的报头,所以能在url中看到
	 * 其他方面与doPost一样
	 * */
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//request.setCharacterEncoding("UTF-8");//设置请求报文的编码，可以得到正确的参数  只适用于doPost
		//response.setCharacterEncoding("UTF-8");//设置响应报文的编码  只适用于doPost
		response.setContentType("text/html;charset=UTF-8");//避免浏览器乱码，默认英文编码处理不了中文字符
		String id=request.getParameter("id");//接收请求端数据,id
		String pwd=request.getParameter("pwd");//接收请求端数据,pwd
		String work=request.getParameter("work");//接收请求端数据,work,work表示身份，选项有"学生"、"教师"、"管理员"
		PrintWriter out = response.getWriter();
		//out.print("test is"+test+"<br>");
		if(id==null||id.equals("")||pwd==null||pwd.equals("")){//验证帐号密码输入是否为空
			out.println("Please Input id or pwd");
			out.close();
			return;
		}
		if(work==null||work.equals("")||work.equals("null")){
			out.println("Please select the work(work表示身份，选项有“学生”、“教师”、“管理员”)");
			out.close();
			return;
		}
		LoginDao login=new LoginDao();//实例化java管理员登录验证类
		boolean flag=login.prepared(id,pwd,work);//调用验证方法
		if(flag){
			out.println("<html><head><title>正在跳转</title></head>");
			String path="";
			String url=" ";
			switch(work){
				case "manager":	path="/管理员登录首页";
								ManagerDao manager=new ManagerDao();
								try {
									entity.setName(manager.getname(id));
									entity.setWork(manager.getwork(id));
								} catch (SQLException e) {}
								break;
				case "teacher": url="<body><script language='javascript'>document.location = 'sportManage/html/教师登录首页.html'</script></body></html>";break;
				case "student": url="<body><script language='javascript'>document.location = 'sportManage/html/学生登录首页.html'</script></body></html>";break;
			}
			RequestDispatcher rd = request.getRequestDispatcher(path);//转发时，路径不要带项目名
			rd.forward(request, response);
			out.println(url);
		}else{
			out.println("pwd is wrong!");
		}
		out.close();
	}
	/*
	 * doPost不会在url中显示parameter属性
	 * doPost的参数放在HTTP请求报文的正文中,所以不能在url中看到
	 * 其他方面与doGet一样
	 * */
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request,response);
	}

}
