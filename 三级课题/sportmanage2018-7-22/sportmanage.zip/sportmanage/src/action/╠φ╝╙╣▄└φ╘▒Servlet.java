package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ManagerDao;

public class 添加管理员Servlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String password1=request.getParameter("password1");
		String password2=request.getParameter("password2");
		String work=request.getParameter("work");
		String date=request.getParameter("date");
		ManagerDao manager=new ManagerDao();
		boolean haveid=false;//根据id在管理员表中查询的结果
		boolean haveadd=false;//记录是否成功添加管理员
		try {
			haveid=manager.query_from_id(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(id.equals("")||id.equals(null)){
			out.print("请输入管理员账号");
		}else if(haveid){
			out.print("管理员账号已存在");
		}else if(password1.equals("")||password1.equals(null)){
			out.print("请输入密码");
		}else if(password1.equals(password2)){
			haveadd=manager.add(id, password1, name, work, date);
		}else{
			out.print("密码不一致");
		}
		if(haveadd){
			out.println("<HTML>");
			out.println("  <HEAD><TITLE>添加管理员</TITLE></HEAD>");
			out.println("  <BODY>"
					+ "添加"+id+"成功"
					+ "<form action='管理员管理'>"
					+ "<input type='submit' value='确认'>"
					+ "</form>"
					+ "");
			out.println("  </BODY>");
			out.println("</HTML>");
		}
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
