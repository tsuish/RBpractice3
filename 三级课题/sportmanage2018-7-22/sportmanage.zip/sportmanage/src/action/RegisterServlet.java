package action;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StudentDao;

public class RegisterServlet extends HttpServlet {
	/*
	 * 默认doGet
	 * doGet会在url中显示parameter属性
	 * doGet的参数放在HTTP请求报文的报头,所以能在url中看到
	 * 其他方面与doPost一样
	 * */
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		String id=request.getParameter("id");
		String year=request.getParameter("year");
		String month=request.getParameter("month");
		String day=request.getParameter("day");
		String birthday=year+month+day;
		String pwd1=request.getParameter("pwd1");
		String pwd2=request.getParameter("pwd2");
		String tel=request.getParameter("tel");
		String email=request.getParameter("email");
		String pwd="";
		boolean flag=false;
		if(id.equals("")||id.equals(null)){
			out.println("学号不能为空");
		}else if(pwd1.equals(pwd2)){
			pwd=pwd1;
			StudentDao student=new StudentDao();
			flag=student.add(id, pwd, birthday, tel, email);
			if(flag){
				out.println("注册成功");
			}else{
				out.println("注册出现错误");
			}
		}else{
			out.println("两次密码不一致");
		}
		out.print("<form action='/sportmanage/sportManage/html/注册.html'>"
		+ "<input type='submit' value='确定'>"
		+ "</form>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request,response);
	}
}
