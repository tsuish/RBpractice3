package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import db.*;
/*
 * 数据操作: 管理员的增删改
 * 
 * 注:查功能待完善
 * */
public class ManagerDao {
/*	private String id;//管理员号
  	private String pwd;//密码
	private String name;//姓名
	private String work;//管理员类别
	private String date;//注册日期
*/	public ManagerDao(){}//无参构造方法
	/*
	 * add(id,pwd,name,work,date)方法作用: 往数据库中添加管理员
	 * 添加成功返回true
	 * 添加失败返回false
	 * */
	public boolean add(String id,String pwd,String name,String work,String date){
		Connection conn = null;											//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		int rows=0;
		try{
			conn=DBConnection.getConnection();
			String sql="insert into tb_manager(id,pwd,name,work,date) values(?,?,?,?,?)";
			perstat=conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(1,id);
			perstat.setString(2,pwd);
			perstat.setString(3,name);
			perstat.setString(4,work);
			perstat.setString(5,date);
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("插入数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConnection.close(perstat);
			DBConnection.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * delete(id)方法作用: 在数据库中删除管理员
	 * 删除成功返回true
	 * 删除失败返回false
	 * */
	public boolean delete(String id) {
		Connection conn = null; 										//连接数据库对象
		PreparedStatement perstat = null; 								//预编译对象
		int rows = 0; 												//更新语句行数变量
		try {
			conn = DBConnection.getConnection(); 						//获取数据库连接
			String sql = "DELETE  FROM tb_manager WHERE id=?";
			perstat = conn.prepareStatement(sql); 						//使用预编译语句进行插入操作
			perstat.setString(1, id); 									//将名称参数设置到SQL语句中
			rows = perstat.executeUpdate();								//执行更新操作
		}catch (Exception e) {									//判断是否发生异常
			JOptionPane.showMessageDialog(null,"删除数据时发生异常","Message",
					JOptionPane.INFORMATION_MESSAGE);			//异常提示
			e.printStackTrace();
		} finally {
			DBConnection.close(perstat);
			DBConnection.close(conn); 								//关闭连接数据库对象资源
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * update(id,pwd,name,work,workid,date)方法作用: 修改数据库中管理员信息
	 * 修改成功返回true
	 * 修改失败返回false
	 **/
	public boolean update(String id,String pwd,String name,String work,String date){
		Connection conn=null;//连接数据库对象
		PreparedStatement perstat=null;//预编译对象
		int rows=0;//更新语句行数变量
		try{
			conn=DBConnection.getConnection();//获取数据库连接
			String sql="update tb_manager set pwd=?,name=?,work=?,date=? where id=?";
			perstat=conn.prepareStatement(sql);//使用预编译语句进行插入操作
			perstat.setString(1,pwd);
			perstat.setString(2,name);
			perstat.setString(3,work);
			perstat.setString(4,date);
			perstat.setString(5,id);
			rows=perstat.executeUpdate();//执行更新操作
		}catch(Exception e){//判断是否发生异常
			JOptionPane.showMessageDialog(null, "修改数据时发生异常！！！",
					"☆★提示信息☆★", JOptionPane.INFORMATION_MESSAGE);//异常提示
			e.printStackTrace();
		}finally{
			DBConnection.close(perstat);
			DBConnection.close(conn);//关闭连接数据库对象资源
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * queryall()方法作用: 在数据库中查询所有管理员
	 * 返回包含所有管理员的ResultSet集合
	 * */
	public ResultSet queryall(){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs =null;
		try{
			conn=DBConnection.getConnection();//获取数据库连接
			String sql="select * from tb_manager";
			perstat=conn.prepareStatement(sql);
			rs=perstat.executeQuery();
		}catch(Exception e){
			e.printStackTrace();
		}
		return rs;
	}
	/*
	 * queryid(id)方法作用: 在数据库中根据账号查询管理员
	 * 返回包含查询到的管理员的ResultSet集合
	 * */
	public ResultSet queryid(String id){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs =null;
		try{
			conn=DBConnection.getConnection();//获取数据库连接
			String sql="select * from tb_manager where id=?";
			perstat=conn.prepareStatement(sql);
			perstat.setString(1,id);
			rs=perstat.executeQuery();
		}catch(Exception e){
			e.printStackTrace();
		}
		return rs;
	}
	/*
	 * query_from_id(id)方法作用: 在数据库中根据管理员号查询管理员
	 * 查到返回true
	 * 查不到返回false
	 * */
	public boolean query_from_id(String id) throws SQLException{
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs =null;
		try{
			conn=DBConnection.getConnection();//获取数据库连接
			String sql="select * from tb_manager where id=?";
			perstat=conn.prepareStatement(sql);
			perstat.setString(1,id);
			rs=perstat.executeQuery();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(rs.next()){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * query2(workid)方法作用: 在数据库中根据管理员类别编号查询管理员
	 * 待完善
	 * */
	public boolean query2(String work){return true;}
	/*
	 * getname(id)方法作用:在管理员表中，根据账号查询姓名
	 * 返回值类型:String型，查到的姓名
	 * */
	public String getname(String id) throws SQLException{
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs =null;
		String name = null;//根据账号查到的姓名
		try{
			conn=DBConnection.getConnection();//获取数据库连接
			String sql="select name from tb_manager where id=?";
			perstat=conn.prepareStatement(sql);
			perstat.setString(1,id);
			rs=perstat.executeQuery();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(rs.next()){
			name= rs.getString(1);
		}
		return name;
	}
	
	
	/*
	 * getwork(id)方法作用:在管理员表中，根据账号查询管理员身份
	 * 返回值类型:String型，查到的姓名
	 * */
	public String getwork(String id) throws SQLException{
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs =null;
		String work = null;//根据账号查到的管理员身份
		try{
			conn=DBConnection.getConnection();//获取数据库连接
			String sql="select work from tb_manager where id=?";
			perstat=conn.prepareStatement(sql);
			perstat.setString(1,id);
			rs=perstat.executeQuery();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(rs.next()){
			work= rs.getString(1);
		}
		return work;
	}
	/*
	 * 测试
	 * */
	public static void main(String[] args) throws SQLException{
		ManagerDao manager=new ManagerDao();
		ResultSet rs=manager.queryall();
		while(rs.next()){
			System.out.print(rs.getObject(1)+"\t");
			System.out.print(rs.getObject(2)+"\t");
			System.out.print(rs.getObject(3)+"\t");
			System.out.print(rs.getObject(4)+"\t"+"\t");
			System.out.print(rs.getObject(5)+"\t");
			System.out.print(rs.getObject(6)+"\t");
			System.out.println();
		}
	}
}
