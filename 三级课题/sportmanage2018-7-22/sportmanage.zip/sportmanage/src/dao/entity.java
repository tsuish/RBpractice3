package dao;

public class entity {
	private static String name;//用户名
	private static String work;//管理员身份
	
	public static String getName() {
		return name;
	}
	public static String getWork() {
		return work;
	}

	

	public static void setName(String name) {
		entity.name = name;
	}
	public static void setWork(String work) {
		entity.work = work;
	}
	
}
