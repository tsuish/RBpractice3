package dao;
import java.sql.*;
import javax.swing.JOptionPane;

import db.*;
/*
 *登录验证
 */
public class LoginDao {
	/*
	 * private String id;//id属性
	 * private String pwd;//密码属性
	 * private String work;//work表示身份，选项有"学生"、"教师"、"管理员"
	 * */	
	public LoginDao(){}//无参构造方法
	/*
	 * prepared(id,pwd,work)方法作用:在数据库中查找用户帐号密码是否正确
	 * 正确返回true
	 * 错误返回false
	 **/
	public boolean prepared(String id,String pwd,String work){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs =null;
		String sql=null;
		try{
			conn=DBConnection.getConnection();
			switch(work){
				case "student": sql = "SELECT * FROM tb_student WHERE id=? and pwd=?";break;
				case "teacher": sql = "SELECT * FROM tb_teacher WHERE id=? and pwd=?";break;
				case "manager": sql = "SELECT * FROM tb_manager WHERE id=? and pwd=?";break;
			}
			perstat = conn.prepareStatement(sql);						//使用PreparedStatement实例执行SQL语句
			perstat.setString(1,id);									//传入用户名
			perstat.setString(2,pwd);								//传入用户密码
			rs = perstat.executeQuery();								//接收查询结果
			if(rs.next()){
				return true ;										//表示查询出来，合法用户
			}
		}catch(Exception e){
			JOptionPane.showMessageDialog(null,"LoginDao登录查询失败！！！","☆★提示信息☆★",
				JOptionPane.INFORMATION_MESSAGE);
		}finally{
			try{
				conn.close() ;										//关闭数据库连接
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"LoginDao关闭数据库失败！！！","☆★提示信息☆★",
						JOptionPane.INFORMATION_MESSAGE);		//提示关闭数据库失败
			}
		}
		return false;												//表示查询不出来，非法用户
	}
}
