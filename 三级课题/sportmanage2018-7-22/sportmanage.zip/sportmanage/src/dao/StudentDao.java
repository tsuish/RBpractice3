package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DBConnection;

/*
 * StudentDao类作用:
 * 数据操作: 学生的增删改
 * *
 * 注:查功能待完善
 * */
public class StudentDao {
	public StudentDao(){}//无参构造方法
	/*
	 * add(id，pwd,birthday,tel,email)方法作用:数据库操作中添加学生
	 * 添加成功返回true
	 * 添加失败返回false
	 * */
	public boolean add(String id,String pwd,String birthday,String tel,String email){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		int rows=0;
		try{
			conn=DBConnection.getConnection();
			String sql="insert into tb_student(id,pwd,birthday,tel,email) values(?,?,?,?,?)";
			perstat=conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(1,id);
			perstat.setString(2,pwd);
			perstat.setString(3,birthday);
			perstat.setString(4,tel);
			perstat.setString(5,email);
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("插入数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConnection.close(perstat);
			DBConnection.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * 注:id(学号),name(姓名),sex(性别),nation(民族),birthday(生日)
	 * 注:schoolid(学校编号),collegeid(学院编号),classid(班级编号),tel(手机号),email(邮箱),work(班级工作)
	 * 
	 * perfect(id,name,sex,nation,birthday,schoolid,collegeid,classid,tel,email,work)方法作用:数据库操作:完善学生个人信息
	 * 完善成功返回true
	 * 完善失败返回false
	 * */
	public boolean perfect(String id,String name,String sex,String nation,String birthday,String schoolid,String collegeid,String classid,String tel,String email,String work){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		int rows=0;
		try{
			conn=DBConnection.getConnection();
			String sql="update tb_student set name=?,sex=?,nation=?,birthday=?,schoolid=?,collegeid=?,classid=?,tel=?,email=?,work=? where id=?)";
			perstat=conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(1,name);
			perstat.setString(2,sex);
			perstat.setString(3,nation);
			perstat.setString(4,birthday);
			perstat.setString(5,schoolid);
			perstat.setString(6,collegeid);
			perstat.setString(7,classid);
			perstat.setString(8,tel);
			perstat.setString(9,email);
			perstat.setString(10,work);
			perstat.setString(11,id);
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("插入数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConnection.close(perstat);
			DBConnection.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * 注:fatherver(父亲姓名),motherver(母亲姓名),homever(宿舍号，三位数)
	 * 密保
	 * securityadd(id,fatherver,motherver,homever)方法作用:数据库操作:学生密保信息完善
	 * 完善成功返回true
	 * 完善失败返回false
	 * */
	public boolean securityadd(String id,String fatherver,String motherver,String homever){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		int rows=0;
		try{
			conn=DBConnection.getConnection();
			String sql="update tb_student set fatherver=?,motherver=?,homever=? where id=?)";
			perstat=conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(1,fatherver);
			perstat.setString(2,motherver);
			perstat.setString(3,homever);
			perstat.setString(4,id);
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("插入数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConnection.close(perstat);
			DBConnection.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/* 注:id(学号),securityver(密保内容),securitywork(密保类别，分fatherver,motherver,homever三种)
	 * 密保
	 * securityquery(id,securityver,securitywork)方法作用:密保验证(三个中的其中一个即可)
	 * */
	public boolean securityquery(String id,String securityver,String securitywork){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		ResultSet rs=null;
		boolean flag=false;
		String sql=null;
		try{
			conn=DBConnection.getConnection();
			switch(securitywork){
				case "fatherver":sql="select * from tb_student where id=? and fatherver=?";break;
				case "motherver":sql="select * from tb_student where id=? and motherver=?";break;
				case "homever":sql="select * from tb_student where id=? and homever=?";break;
			}
			perstat=conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(1,id);
			perstat.setString(2,securityver);
			rs=perstat.executeQuery();//接收查询结果
			if(rs.next()){
				flag=true;
			}
		}catch(Exception e){
			System.out.println("插入数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConnection.close(perstat);
			DBConnection.close(conn);
		}
		if(flag){
			return true;
		}else{
			return false;
		}
	}
}
