package db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
public class DBConnection {
	private static String dbUrl="jdbc:mysql://localhost:3306/data_sport";
	private static String dbUser="root";
	private static String dbPassword="root";
	private static String jdbcName="com.mysql.jdbc.Driver";
	//连接数据库
	public static Connection getConnection(){
		Connection conn = null;
		try{
			Class.forName(jdbcName);
		}
		catch(Exception e){}
		try{
			conn=DriverManager.getConnection(dbUrl,dbUser,dbPassword);
		}
		catch(SQLException ex){}
		return conn;		
	}
	// 关闭连接数据库资源
	public static void close(Connection conn) {
		if (conn != null) {															//判断Connection对象是否为空
			try {
				conn.close(); 														// 关闭连接数据库资源
			} catch (SQLException e){ 												//判断关闭Connection对象时是否发生异常
				System.out.println("关闭数据库连接发生异常");
			}
		}
	}
	//关闭操作数据库资源
	public static void close(Statement stmt) {
		if (stmt != null){ 															//判断Statement对象是否为空
			try {
				stmt.close(); 														//关闭操作数据库资源
			} catch (SQLException e){ 												//判断关闭Statement对象时是否发生异常
				JOptionPane.showMessageDialog(null,"关闭数据库操作资源发生异常！！！","☆★提示信息☆★",
						JOptionPane.INFORMATION_MESSAGE);							//提示关闭数据库操作资源发生异常
			}
		}
	}
	//关闭结果集
	public static void close(ResultSet rs) {
		if (rs != null) {															//判断结果集是否为空
			try {
				rs.close();															//关闭结果集
			} catch (SQLException e){ 												//判断结果集是否发生异常
				JOptionPane.showMessageDialog(null,"关闭结果集发生异常！！！","☆★提示信息☆★",
						JOptionPane.INFORMATION_MESSAGE);							//提示关闭结果集发生异常
			}
		}
	}
}
