package html;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ManagerDao;

public class 修改管理员 extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		String id=(String) request.getAttribute("id");
		ManagerDao manager=new ManagerDao(); 
		ResultSet rs=manager.queryid(id);
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>修改管理员</TITLE></HEAD>");
		try {
			out.println("  <BODY>"
					+ "<form action='修改管理员Servlet'>");
			if(rs.next()){
			out.println("账号<input type='text' name='id' value='"+rs.getObject(1)+"'><br>"
					+ "密码<input type='password' name='pwd' value='"+rs.getObject(2)+"'><br>"
					+ "姓名<input type='text' name='name' value='"+rs.getObject(3)+"'><br>"
					+ "身份<input type='text' name='work' value='"+rs.getObject(4)+"'><br>"
					+ "注册日期<input type='text' name='date' value='"+rs.getObject(5)+"'><br>");
			}
			out.println("<input type='submit' value='修改'>"
					+ "</form>");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
