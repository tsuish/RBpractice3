package html;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ManagerDao;

public class 管理员管理 extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{

		response.setContentType("text/html;charset=utf-8");
		ManagerDao managerall=new ManagerDao(); 
		ResultSet rs=managerall.queryall();
		PrintWriter out = response.getWriter();
		out.println("<HTML>"
				+ "<HEAD>"
				+ "		<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>"
				+ "		<TITLE>管理员管理</TITLE>"
				+ "		<link type='text/css' rel='stylesheet' href='sportManage/css/管理人员.css' />"
				+ "</HEAD>"
				+ "<BODY>"
				+ "		<div id='mydiv'>"
				+ "<a href='LoginServlet?id=1&pwd=1&work=manager'><</a>"
				+ "<form action='管理员管理Servlet'>"
				+ "			<table align='center'>"
				+ "				<tr>"
				+ "					<th>"
				+ "账号"
				+ "					</th>"
				+ "					<th>"
				+ "姓名"
				+ "					</th>"
				+ "					<th>"
				+ "身份"
				+ "					</th>"
				+ "					<th>"
				+ "注册日期"
				+ "					</th>"
				+ "				</tr>");
	try {
		while(rs.next()){ 
		out.println("			<tr>"
				+ "					<th>"
				+rs.getObject(1)
				+ "					</th>"
				+ "					<th>"
				+ rs.getObject(3)
				+ "					</th>"
				+ "					<th>"
				+ rs.getObject(4)
				+ "					</th>"
				+ "					<th>"
				+ rs.getObject(5)
				+ "					</th>"
				+ "					<th>"
				+ "<input type='radio' name='choice' value='"+rs.getObject(1)+"'>"
				+ "					</th>"
				+ "				</tr>");
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		out.print( "			<tr>"
				+ "<th>"
				+ ""
				+ "</th><th></th>"
				+ "					<th>"
				+ "						<select name='exe'>"
				+ "							<option value='修改'>修改</option>"
				+ "							<option value='添加'>添加</option>"
				+ "							<option value='删除'>删除</option>"
				+ "						</select>"
				+ "<input type='submit' value='执行操作'>"
				+ "					</th>"
				+ "					<th>"
				+ "					</th>"
				+ "				</tr>"
				+ "	</table>"
				+ "	</div>"
				+ "</form>"
				+ "</BODY>"
				+"</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
