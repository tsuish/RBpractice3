package html;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.entity;

public class 管理员登录首页 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("  <HEAD>"
				+ "<link type='text/css' rel='stylesheet' href='sportManage/css/管理员登录首页.css' />"
				+ "<title>管理员登录首页</title>"
				+ "<div style='position:absolute;top:20px;left:1100px;color:#FFF'>"
				+ "<a href='/sportmanage/sportManage/html/登录.html'><</a>"
				+ "		<font color='darkblue'>欢迎,"+entity.getName()+"<br>您的身份:"+entity.getWork()+"</font>"
				+ "<form action='"+entity.getWork()+"'>"
				+ "		<a name='test' value='1'></a>"
				+ "		<input type='submit' value='"+entity.getWork()+"'>"
				+ "</from>"
				+ "		<br><a href='sportManage/html/index.html' style='text-decoration: none;'>返回首页</a>"
				+ "		<a href='#' style='text-decoration: none;' onclick='ShowDiv('MyDiv','fade')'>|个人信息</a>"
				
				+ "</div>"
				+ "<img src='sportManage/img/9.PNG' style='width:100%;height: 185px;'/>"
				+ "<div style='background-color: #bbbbbb;width: 100%;height: 500px;'>"
				+ "</HEAD>");
		out.println("  <BODY>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
