package html;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.entity;

public class 添加管理员 extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		Date now =new Date();
		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		String date=dateFormat.format(now);
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>添加管理员</TITLE></HEAD>");
		out.println("  <BODY>"
				+ "<form action='添加管理员Servlet'>"
				+ "账号<input type='text' name='id'><br>"
				+ "姓名<input type='text' name='name'><br>"
				+ "密码<input type='password' name='password1'><br>"
				+ "密码确认<input type='password' name='password2'><br>"
				+ "身份<select name='work'>"
				+ "		<option value='管理员管理'>管理员管理</option>"
				+ "		<option value='注册管理'>注册管理</option>"
				+ "		<option value='现场项目管理'>现场项目管理</option>"
				+ "		<option value='新闻公告管理'>新闻公告管理</option>"
				+ "		<option value='报名管理员'>报名管理员</option>"
				+ "		<option value='裁判'>裁判</option>"
				+ "		<option value='成绩管理'>成绩管理</option>"
				+ "</select><br>"
				+ "注册日期<input type='text' name='date' value='"+date+"'><br>"
				+ "<input type='submit' value='添加'>"
				+ "</form>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
